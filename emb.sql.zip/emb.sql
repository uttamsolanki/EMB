-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 14, 2015 at 08:17 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `emb_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_design`
--

CREATE TABLE IF NOT EXISTS `tbl_design` (
  `d_id` int(11) NOT NULL AUTO_INCREMENT,
  `design_name` varchar(50) NOT NULL,
  `stiches` bigint(20) NOT NULL,
  `design_category` varchar(50) NOT NULL,
  `design_type` varchar(50) NOT NULL,
  `design_subtype` varchar(50) NOT NULL,
  `design_desc` text NOT NULL,
  `design_pic` varchar(50) NOT NULL,
  `design_emb` varchar(50) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`d_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_design`
--

INSERT INTO `tbl_design` (`d_id`, `design_name`, `stiches`, `design_category`, `design_type`, `design_subtype`, `design_desc`, `design_pic`, `design_emb`, `created_at`) VALUES
(1, 'design_1', 1000, 'Multi', 'Saree', 'Skirt', 'design', '98112-bg.jpg', '44397-90979-009.emb', '2015-10-03');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_design_subtype`
--

CREATE TABLE IF NOT EXISTS `tbl_design_subtype` (
  `dst_id` int(11) NOT NULL AUTO_INCREMENT,
  `dt_id` int(11) DEFAULT NULL COMMENT 'Id of tbl_design_type table',
  `design_subtype_name` varchar(50) NOT NULL,
  PRIMARY KEY (`dst_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_design_subtype`
--

INSERT INTO `tbl_design_subtype` (`dst_id`, `dt_id`, `design_subtype_name`) VALUES
(1, 1, 'Pallu'),
(2, 1, 'Skirt'),
(3, 1, 'Lace'),
(4, 1, 'Kali'),
(5, 1, 'Blouse'),
(6, 1, 'Patch'),
(7, 1, 'Butta'),
(8, 1, 'Set'),
(9, 2, 'Top'),
(10, 2, 'Dupatta'),
(11, 2, 'Lace'),
(12, 2, 'Neck'),
(13, 2, 'Single Head'),
(14, 2, 'Patch'),
(15, 2, 'Butta'),
(16, 2, 'Set');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_design_type`
--

CREATE TABLE IF NOT EXISTS `tbl_design_type` (
  `dt_id` int(11) NOT NULL AUTO_INCREMENT,
  `design_type_name` varchar(50) NOT NULL,
  PRIMARY KEY (`dt_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_design_type`
--

INSERT INTO `tbl_design_type` (`dt_id`, `design_type_name`) VALUES
(1, 'Saree'),
(2, 'Dress');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_register`
--

CREATE TABLE IF NOT EXISTS `tbl_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_register`
--

INSERT INTO `tbl_register` (`id`, `email`, `password`) VALUES
(1, 'mbawman', '158');
