$(document).ready(function () {
  $(".button-collapse").sideNav();	
  $('.slider').slider({full_width: true});    
});
